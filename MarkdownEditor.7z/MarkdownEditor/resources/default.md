﻿# Welcome to Yang's Blog!
this is a most simple demo, used markdown-it and highlight.js in the browser to rendering markdown files
## used markdown-it in the browser

> 你好！ 这是你第一次使用 **Markdown编辑器** 所展示的欢迎页。如果你想学习如何使用Markdown编辑器。

可以仔细阅读这篇文章，了解一下Markdown的基本语法知识。
***
Rendered by **markdown-it**.
### 表格demo,欢迎使用Markdown
Name    | Age
--------|------
Bob     | 27
Alice   | 23

### 代码高亮例子
```golang
package main
import "fmt"

func main() {
	fmt.Println("hello ")
}

```

# 一级标题

## 二级标题

### 三级标题


### 表格例子 欢迎使用Markdown
| Command | Description |
| --- | --- |
| `git status` | List all *new or modified* files |
| `git diff` | Show file differences that **haven't been** staged |

### 链接
[baidu](https://baidu.com)


### 插入图片
![imgs](https://img-blog.csdnimg.cn/2019091813595558.png)

![imgs](file:///G:/Picture/wallpaper/beemo.jpg)


- 项目
  - 项目
	- 项目

- 列表信息
	+ 二级列表
		* 三级列表

1. 项目1
2. 项目2
3. 项目3

- [ ] 计划任务
- [x] 完成任务

创建脚注格式类似这样 [^RUNOOB]

> 最外层
> > 第一层嵌套
> > > 第二层嵌套

```mermaid
graph TD
A[方形1111111111] --> B(圆角22222222)
	B --> C{条件a333}
	C --> |a=1| D[结果14444]
	C --> |a=2| E[结果25555]
	F[竖向流程图]
```

```javascript
var defaults = {
	  html: false,
	  xhtmlOut: false,
	  breaks: false,
	  langPrefix: 'language-',
	  linkify: true,
	  typographer: true,

	  _highlight: true,
	  _strict: false,
	  _view: 'html'
	};
```
